package com.Dirito.Chat;

public class PiKaQiu
{
	static void pkq()
	{
		String pikaqiu_one = "　　 へ　　　　　／|\n　　/＼7　　∠＿/\n　 /　│　　 ／　／\n";
		String pikaqiu_two = "　│　Z ＿,＜　／　　 /`ヽ\n　│　　　　　ヽ　　 /　　〉\n　 Y　　　　　`　 /　　/\n";
		String pikaqiu_three = "　ｲ●　､　●　　⊂⊃〈　　/\n　()　 へ　　　　|　＼〈\n　　>ｰ ､_　 ィ　 │ ／／\n";
		String pikaqiu_latString = "　 / へ　　 /　ﾉ＜| ＼＼\n　 ヽ_ﾉ　　(_／　 │／／\n　　7　　　　　　　|／\n　　＞―r￣￣`ｰ―＿\n";
		String pikaqiu = pikaqiu_one + pikaqiu_two + pikaqiu_three + pikaqiu_latString;
		//System.out.println(pikaqiu);
		String q = ("　　 へ　　　　　／|");
		String w = ("　　/＼7　　∠＿/");
		String e = ("　 /　│　　 ／　／");
		
		String r = ("　│　Z ＿,＜　／　　 /`ヽ");
		String t = ("　│　　　　　ヽ　　 /　　〉");
		String y = ("　 Y　　　　　`　 /　　/");
		
		String u = ("　ｲ●　､　●　　⊂⊃〈　　/");
		String i = ("　()　 へ　　　　|　＼〈");
		String o = ("　　>ｰ ､_　 ィ　 │ ／／");
		
		String p = ("　 / へ　　 /　ﾉ＜| ＼＼");
		String a = ("　 ヽ_ﾉ　　(_／　 │／／");
		String s = ("　　7　　　　　　　|／");
		String d = ("　　＞―r￣￣`ｰ―＿");
		Writter.write("\n", Writter.path);
		Writter.write(q, Writter.path);
		Writter.write("\n", Writter.path);
		Writter.write(w, Writter.path);
		Writter.write("\n", Writter.path);
		Writter.write(e, Writter.path);
		Writter.write("\n", Writter.path);
		Writter.write(r, Writter.path);
		Writter.write("\n", Writter.path);
		Writter.write(t, Writter.path);
		Writter.write("\n", Writter.path);
		Writter.write(y, Writter.path);
		Writter.write("\n", Writter.path);
		Writter.write(u, Writter.path);
		Writter.write("\n", Writter.path);
		Writter.write(i, Writter.path);
		Writter.write("\n", Writter.path);
		Writter.write(o, Writter.path);
		Writter.write("\n", Writter.path);
		Writter.write(p, Writter.path);
		Writter.write("\n", Writter.path);
		Writter.write(a, Writter.path);
		Writter.write("\n", Writter.path);
		Writter.write(s, Writter.path);
		Writter.write("\n", Writter.path);
		Writter.write(d, Writter.path);
		
	}
}
