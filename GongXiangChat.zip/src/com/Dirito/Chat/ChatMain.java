package com.Dirito.Chat;
import java.io.IOException;

import com.Dirito.DuoXianCheng.DXC_Reload;
import com.Dirito.DuoXianCheng.DXC_Write;

public class ChatMain
{
	public static int maincon,mainpcon;
	public static void main(String[] args) throws IOException
	{
		Player player = new Player();
		player.AutoPath();
		//player.SetPath();
		player.SetID();
		player.SetPChat();
		player.RenZheng();
		Writter.tcon = Writter.PanDuanHang(Writter.path);
		Writter.pcon = Writter.PanDuanHang(Writter.pchat);
		maincon = Writter.tcon;
		mainpcon = Writter.pcon;//����������maincon��

		//���߳�������д��
		DXC_Reload Day = new DXC_Reload();
		DXC_Write Night = new DXC_Write();
		Day.start();
		Night.start();
		
	}
}