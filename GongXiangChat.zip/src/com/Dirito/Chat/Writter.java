package com.Dirito.Chat;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.util.Scanner;

public class Writter
{
	//����log��·��
	public static String CorePath;
    public static String path;
    public static String idlist;
    public static String pchat;
    public static String duixiang;
    public static int tcon;
    public static int pcon;
    
    //����UserID�ļ���д��ID
    public static void CreateID() throws IOException
    {
		File SelfID = new File(Player.panfu+":\\SelfID.txt");
		SelfID.createNewFile();
		Player.ID = (Integer.parseInt(ShuChu(idlist))) + 1;
		write(Integer.toString(Player.ID),idlist);
		write("\n", idlist);
    	write(Integer.toString(Player.ID), Player.panfu+":\\SelfID.txt");
    }
    

	//�������log�Ի�д��WenBen�ı�
	public static void write(String log,String WenBen) 
	{
        BufferedWriter out = null;
		try
			{
				out = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(WenBen,true)));
			} catch (FileNotFoundException e1)
			{
				// TODO �Զ����ɵ� catch ��
				e1.printStackTrace();
			}
        try
			{
				out.write(log);
			} catch (IOException e)
			{
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
        try
			{
				out.close();
			} catch (IOException e)
			{
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
	}
	
	//����log�жԻ��ж�����
	public static  int PanDuanHang(String p) throws IOException
	{
		String str;
		int count = 0;
		FileReader fr = new FileReader(p);
		BufferedReader bfr =new BufferedReader(fr);
		while((str = bfr.readLine()) != null)//����log��ÿһ�仰
		{
		count++;
		}
		fr.close();
		return count;
	}
	
	//����log���һ�е��ı����
	public static String ShuChu(String path)
	{
		String TrueLine = null;
		FileReader fileReader = null;
		try {
			fileReader = new FileReader(path);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		Scanner sc = new Scanner(fileReader);
		String line = null;
		while((sc.hasNextLine()&&(line=sc.nextLine())!=null)){
			if(!sc.hasNextLine()){
				TrueLine = line;
			}
		}
		sc.close();
		return TrueLine;
	}

}
