package com.Dirito.DuoXianCheng;

import com.Dirito.Chat.Commander;
import com.Dirito.Chat.Player;
import com.Dirito.Chat.Writter;

public class DXC_Write extends Thread
{
	public void run() 
	{
		while(true)
			{
				Player.Typeing();
				if(Player.NR.startsWith("/"))
					{
						Commander.command();
						continue;
					}
				if(!Player.NR.equals("") && Player.DuiXiangID==0)
					{
						Writter.write("\r"+Player.NeiRong+"\r\n",Writter.path);					
					}
				else {
					Writter.write("\r"+Player.DXNR+"\r\n", Writter.CorePath+"PChat\\"+Player.DuiXiangID+".txt");
					System.out.println(Player.NeiRong);
				}
			}
	}
}