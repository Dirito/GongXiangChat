package com.Dirito.DuoXianCheng;

import java.io.IOException;
import com.Dirito.Chat.ChatMain;
import com.Dirito.Chat.Writter;

public class DXC_Reload extends Thread 
{
	public void run()
	{
		while(true)
			{
				try
					{
						Writter.tcon = Writter.PanDuanHang(Writter.path);
						Writter.pcon = Writter.PanDuanHang(Writter.pchat);
					} catch (IOException e)
					{
						
						e.printStackTrace();
					}
				if(Writter.tcon>ChatMain.maincon)
					{
						System.out.println(Writter.ShuChu(Writter.path));
						ChatMain.maincon = Writter.tcon;
					}
				if(Writter.pcon > ChatMain.mainpcon)
					{
						System.out.println(Writter.ShuChu(Writter.pchat));
						ChatMain.mainpcon = Writter.pcon;
					}
				
			}
		
	}
}