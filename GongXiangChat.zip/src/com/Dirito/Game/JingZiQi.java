package com.Dirito.Game;

import com.Dirito.Chat.Writter;

public class JingZiQi
{
	public static void start()
	{
		String []qipu = {" "," "," "," "," "," "," "," "," "};
		String QiPu = "=======\n|"+qipu[0]+"|"+qipu[1]+"|"+qipu[2]+"|\n"+"|"+qipu[3]+"|"+qipu[4]+"|"+qipu[5]+"|\n"+"|"+qipu[6]+"|"+qipu[7]+"|"+qipu[8]+"|\n=======";
		System.out.println(QiPu);
	}	
	
}

